Created By starfire
http://starfire.deviantart.com/
Downloaded @ www.Cursors-4U.com
=====================================

Medieval fantasy-like cursor pack for Windows XP. Non-animated *.cur files, NO additional Software required. True Color 24 bit + 8 bit alpha version only.
I'm rather fond of fantasy and archaic weapons, and wanted to create a cursor that somehow stands out of the crowd. I also tried to make best use of the XP alpha channel effects, like generating halos with opacity gradients. However, you need to have the XP visual enhancements activated to see them. If the cursors look weird on your desktop, then you have probably deactivated the some XP visuals to save performance. Don't do this ;)



At first only its tip was visible, but then it rose, straight, proud, all that was noble and great and wondrous. The tip of the blade pointed toward the moon, as if it would cleave it in two. The blade itself gleamed like a beacon in the night. There was no light source for the sword to be reflecting from, for the moon had darted behind a cloud in fear. The sword was glowing from the intensity of its strength and power and knowledge that it was justice incarnate, and that after a slumber of uncounted years its time had again come. After the blade broke the surface, the hilt was visible, and holding the sword was a single strong, yet feminine hand, wearing several rings that bore jewels sparkling with the blue-green color of the ocean.
[ Knight Life, by Peter David ]